<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<me','mikhmon>|>pZY=');




$data['PANCASAN.ID'] = array ('1'=>'PANCASAN.ID!id-26.hostddns.us:5323','PANCASAN.ID@|@waryourasta@gmail.com','PANCASAN.ID#|#jJKfqJKgaWNlWQ==','PANCASAN.ID%PANCASAN.ID','PANCASAN.ID^PANCASAN.ID','PANCASAN.ID&Rp','PANCASAN.ID*10','PANCASAN.ID(1','PANCASAN.ID)','PANCASAN.ID=10','PANCASAN.ID@!@enable');

$data['OpingNET'] = array ('1'=>'OpingNET!10.10.10.1','OpingNET@|@waryourasta@gmail.com','OpingNET#|#jJKfqJKgaWNlWQ==','OpingNET%OpingNET','OpingNET^oping.net','OpingNET&Rp','OpingNET*10','OpingNET(1','OpingNET)','OpingNET=10','OpingNET@!@enable');
$data['Karangbawang.net'] = array ('1'=>'Karangbawang.net!id-11.hostddns.us:3005','Karangbawang.net@|@neverdie','Karangbawang.net#|#n6qkp6RicWk=','Karangbawang.net%Karangbawang.net','Karangbawang.net^Karangbawang.net','Karangbawang.net&Rp','Karangbawang.net*10','Karangbawang.net(1','Karangbawang.net)','Karangbawang.net=10','Karangbawang.net@!@disable');